import attrs
import typing as T
import json
from elit.components.tokenizer import EnglishTokenizer

tokenizer = EnglishTokenizer()

@attrs.define
class DialogueCS:
    """
    Each context with all inferences
    """
    id: str
    source: str
    context: list[str, ...]
    speaker1: T.Union[str, None]
    speaker2: T.Union[str, None]
    speakerlist: T.Union[list[str, ...], None]

    inferences: dict[str, dict[str, list[str, ...]]] = attrs.Factory(dict)

    def add_new_inference(self, target, cs_type, answers_ls):
        if isinstance(answers_ls, str):
            answers_ls = [answers_ls]
        assert isinstance(answers_ls, list)
        answers_ls = [a.strip() for a in answers_ls]
        if isinstance(cs_type, tuple):
            cs_type = tuple(t.strip() for t in cs_type)
        self.inferences.setdefault(target, {}).setdefault(cs_type, []).extend(answers_ls)

    def has_inference(self, target, cs_type, answer):
        return answer in self.inferences.get(target, {}).get(cs_type, [])

    def get_full_target(self, target):
        full_target = [utter for utter in self.context if target in utter]
        assert len(full_target) == 1
        return full_target[0]

    def target_is_question(self, target):
        full_target = self.get_full_target(target)
        tokenized_sentences = tokenizer.segment(tokenizer.tokenize(full_target))
        count_sentences = len(tokenized_sentences)
        count_questions = sum([1 for s in tokenized_sentences if '?' in s[-1]])
        question_terminated = '?' in tokenized_sentences[-1][-1]
        if count_questions == count_sentences:
            return True
        return False


@attrs.define
class DatasetsCS:
    train: dict[str, DialogueCS]
    val: dict[str, DialogueCS]
    test: dict[str, DialogueCS]

    def iterate(self):
        return [('train', self.train), ('val', self.val), ('test', self.test)]


@attrs.define
class DialogueCSDatapoint:
    """
    Represents a single individual inference for a particular context
    """
    id: str
    source: str
    context: list[str, ...]
    target: str
    speaker1: T.Union[str, None]
    speaker2: T.Union[str, None]
    speakerlist: T.Union[list[str], None]
    relation: T.Union[str, None]
    generation: T.Union[str, None]

    def display(self, show_target=True):
        if '<idx>' in self.target:
            idx, target = self.target.split('<idx>')
            idx = int(idx)
        else:
            idx = len(self.context)-1
        return display_context(self, stop_at=idx+1, target=idx if show_target else None)

def _concat_consecutive(lines, speakers):
    processed_lines = []
    idx_mapping = {}
    prev_speaker = None
    for i, (line, speaker) in enumerate(zip(lines, speakers)):
        if speaker == prev_speaker:
            processed_lines[-1] += ' ' + line
            idx_mapping[i] = idx_mapping[i-1]
        else:
            processed_lines.append(line)
            idx_mapping[i] = idx_mapping[i-1] + 1 if len(idx_mapping) > 0 else 0
        prev_speaker = speaker
    return processed_lines, idx_mapping

def add_speaker_to_lines(lines: list[str]) -> str:
    elements = list(
        reversed(
            [
                f"{'Speaker' if i % 2 == 0 else 'Listener'}: {u}"
                for i, u in enumerate(reversed(lines))
            ]
        )
    )
    dia = '\n'.join(elements)
    return dia

def display_context(datapoint, stop_at=None, target=None):
    """
    if consecutive speakers, concatenate turns!
    """
    if stop_at is None:
        stop_at = len(datapoint.context)
    lines = datapoint.context[:stop_at]
    if datapoint.speakerlist is not None:
        speakers = datapoint.speakerlist[:len(lines)]
        processed_lines, idx_mapping = _concat_consecutive(lines, speakers)
    else:
        processed_lines = lines
        idx_mapping = {i:i for i in range(len(processed_lines))}
    dia = add_speaker_to_lines(processed_lines)
    if target is not None:
        dia += f'\n\nTarget: {processed_lines[idx_mapping[target]]}'
    return dia

templates = {
    'antecedent': ("What events happened before the situation that Speaker just shared?", "Before this, ..."),
    'effect': ("What does the last thing said cause to happen?", "This causes..."),
    'effect_s': ("How does the last thing said affect Speaker?", "This causes Speaker to..."),
    'effect_o': ("How does the last thing said affect Listener?", "This causes Listener to..."),
    'subsequent': ("What might happen after what Speaker just said?", "After this, ..."),
    'prerequisite': ("What prerequisites are required for the last thing said to occur?", "For this to happen, it must be true that..."),
    'cause': ("What could have caused the last thing said to happen?", "This was caused by..."),
    'attribute': ("What is a likely characteristic of Speaker based on what they just said?", "Speaker is..."),
    'motivation': ("What is an emotion or human drive that motivates Speaker based on what they just said?", "Speaker is motivated..."),
    'reaction': ("How is Speaker feeling after what they just said?", "Speaker feels..."),
    'reaction_o': ("How does Listener feel because of what Speaker just said?", "Listener feels..."),
    'desire': ("What does Speaker want to do next?", "As a result, Speaker wants..."),
    'desire_o': ("What will Listener want to do next based on what Speaker just said?", "As a result, Listener wants..."),
    'constituents': ("What is a breakdown of the last thing said into a series of required subevents?", "This involves..."),
    'obstacle': ("What would cause the last thing said to be untrue or unsuccessful?", "This is untrue or unsuccessful if...")
}

import os
import openai
import time
import json
import re
from data.soda.gpt_utils import Prompt
from data.soda.data_definitions import DialogueCSDatapoint, templates
import multiprocessing as mp

class Infer(Prompt):
    """
    Generate inferences for the provided conversation of the specified question type
    """
    template = """{}

Question: {}
Answer Format: {}

In a list titled "Answers", generate {} to this question for the target expression, keeping the rest of the conversation in mind.
Your answers should provide novel information that is not explicitly shared in the conversation.
"""


def answers_to_list(generated):
    generated_lines = [x.strip() for x in generated.split('\n') if x.strip() != '']
    answers_start = False
    answers = []
    for line in generated_lines:
        if answers_start:
            if line.startswith('-'):
                line = line[1:]
            elif m := re.match('[0-9]+[.)]', line):
                line = line[m.span()[1]:]
            else:
                print('Parser did not find parse!')
                print(f'\t{line}')
                print()
                continue
            answers.append(line.strip())
        else:
            if line.startswith('Answers:'):
                answers_start = True
    return answers

def gen(tasks, k, file_prefix):
    openai.api_key = os.getenv("OPENAI")
    generations = []
    total_tokens = 0
    ts = time.time()
    for j, (convo, type, q, a) in enumerate(tasks):
        if (j+1) % 5 == 0:
            print(f'Process {k} is starting task {j + 1} of {len(tasks)}', flush=True)
        full_context = convo.display()
        generator = Infer(full_context, q, a, "several likely answers", parse=answers_to_list)
        s = time.perf_counter()
        generated, output, used_tokens = generator.generate()
        dur = time.perf_counter() - s
        generations.append({
            'source': 'soda',
            'id': convo.id,
            'target': convo.target,
            'type': type,
            'question': q,
            'answer_prefix': a,
            'elapsed': f"{int(dur)}",
            'prompt': generator.prompt,
            'generated': generated,
            'output': output,
            'full': generator.prompt.split('\n') + generated.split('\n'),
            'used_tokens': used_tokens
        })
        total_tokens += used_tokens
    print(f'Process {k} completed {j + 1}/{len(tasks)} tasks')
    print(f'\t{total_tokens:,} tokens used in {(time.time() - ts) / 60:.1f} min', flush=True)
    json.dump(generations, open(f'{file_prefix}{k}th_proc.json', 'w'), indent=2)



def gen_multiprocess(tasks, procs, file_prefix):
    tasks = [tasks[i::procs] for i in range(procs)]
    with mp.Pool(procs) as pool:
        pool.starmap(
            gen,
            [(tasks[i], i, file_prefix) for i in range(procs)]
        )

def get_all_soda_data():
    soda_data = json.load(open('data/soda/selected_soda_for_generation.json'))
    RUNS = 0
    RUNE = 12000
    return list(soda_data.items())[RUNS:RUNE]



if __name__ == '__main__':

    types = [
        'subsequent',
        'prerequisite',
        'cause',
        'attribute',
        'motivation',
        'reaction',
        'reaction_o',
        'desire',
        'desire_o',
        'constituents',
    ]

    data = get_all_soda_data()

    convo_objects = [
        DialogueCSDatapoint(
            id=clustername,
            source='soda',
            context=convo_dict["selected_context"],
            target=convo_dict["selected_context"][-1],
            speaker1=convo_dict["speakers"][0],
            speaker2=convo_dict["speakers"][1],
            speakerlist=convo_dict["speakers"],
            relation=None,
            generation=None
        )
        for clustername, convo_dict in data
    ]

    tasks = [(convo, type, *templates[type]) for convo in convo_objects for type in types]

    gen_multiprocess(
        tasks=tasks,
        procs=1,
        file_prefix=f'data/soda/raw_generations/'
    )


